let terrain = [];
let cols, rows;
let scl = 20;
let w = 600;
let h = 600;

function setup() {
    createCanvas(600, 600, WEBGL);
    cols = w / scl;
    rows = h / scl;

    // 지형 데이터 생성
    let yoff = 0;
    for (let y = 0; y < rows; y++) {
        let xoff = 0;
        terrain[y] = [];
        for (let x = 0; x < cols; x++) {
            terrain[y][x] = map(noise(xoff, yoff), 0, 1, -100, 100);
            xoff += 0.1;
        }
        yoff += 0.1;
    }
}

function draw() {
    background(0, 100); // 배경 색상과 투명도 설정
    rotateX(PI / 3);
    translate(-w / 2, -h / 2 + 100);
    fill(0, 255, 0, 200); // 지형 색상과 투명도 설정
    for (let y = 0; y < rows - 1; y++) {
        beginShape(TRIANGLE_STRIP);
        for (let x = 0; x < cols; x++) {
            vertex(x * scl, y * scl, terrain[y][x]);
            vertex(x * scl, (y + 1) * scl, terrain[y + 1][x]);
        }
        endShape();
    }

    // 자동차 그리기
    translate(w / 2 - 100, h / 2 - 100, 0);
    fill(255, 0, 0); // 자동차 색상
    box(50, 30, 20); // 자동차 본체

    // 조명 추가
    ambientLight(100); // 주변 조명
    directionalLight(255, 255, 255, 0, -1, 0); // 방향 조명
}
